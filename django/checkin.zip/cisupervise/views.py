from django.shortcuts import render

# Create your views here.
from django.http import HttpResponse
from django.http import JsonResponse
from .models import Supervise
import os
import json

def get(request):
    # Get all data as a list of dictionaries
    #dict_json = {numbers='',log=''}
    numbers = list(Supervise.objects.values_list('number', flat=True))
    logs = sorted(os.listdir("/share/htdocs/supervise"))
    dict_json = {'numbers':numbers, 'log':logs}
    # safe=False is required for non-dict objects
    return JsonResponse(dict_json, safe=False)
def delete(request):
    # Get all data as a list of dictionaries
    #dict_json = {numbers='',log=''}
    #numbers = list(Supervise.objects.values_list('number', flat=True))
    #logs = sorted(os.listdir("/share/htdocs/supervise"))
    #dict_json = {'numbers':numbers, 'log':logs}
    Supervise.objects.get(number=request.GET['number']).delete()
    # safe=False is required for non-dict objects
    return HttpResponse("gg")
def numbers(request):
    # Get all data as a list of dictionaries
    #dict_json = {numbers='',log=''
    if request.method == "GET":
        numbers = list(Supervise.objects.values_list('number', flat=True))
        pngs = [f.replace(".png", "") for f in os.listdir("/share/htdocs/supervise")]
        logs = sorted(pngs)
        #logs = sorted(os.listdir("/share/htdocs/supervise"))
        dict_json = {'numbers':numbers, 'log':logs}
    # safe=False is required for non-dict objects
        return JsonResponse(dict_json, safe=False)
    if request.method == "POST":
        #Supervise.number.get(pk=request.GET["number"]).save()
        try:
            # Decode the request body and parse the JSON data
            data = json.loads(request.body.decode('utf-8'))
            
            # Access the data as a Python dictionary
            numberpost = data.get('number')
            #email = data.get('email')
            Supervise.objects.create(number=numberpost)
            # Process your data (e.g., save to database)
            #print(f"Received data: Name - {name}, Email - {email}")
            return HttpResponse("post")
            #return JsonResponse({'message': 'Data received successfully!', 'name': name}, status=200)
        except json.JSONDecodeError:
            return JsonResponse({'error': 'Invalid JSON'}, status=400)
        
    # safe=False is required for non-dict objects
        #return HttpResponse("post")
    if request.method == "DELETE":
        #Supervise.number.get(pk=request.GET["number"]).save()
        Supervise.objects.get(number=request.GET['number']).delete()
    # safe=False is required for non-dict objects
        return HttpResponse("delete")
def index(request):
    #latest_question_list = Question.objects.order_by("-pub_date")[:5]
    jsindex = 0 if ".js" in os.listdir("/media/vue-supervise/dist/assets")[0] else 1
    cssindex = 0 if ".css" in os.listdir("/media/vue-supervise/dist/assets")[0] else 1
    
    
    context = {"js": os.listdir("/media/vue-supervise/dist/assets")[jsindex],"css": os.listdir("/media/vue-supervise/dist/assets")[cssindex]}
    return render(request, "supervise.html", context)