from django.urls import path

from . import views

urlpatterns = [
    path("get", views.get, name="get"),
    path("delete", views.delete, name='delete'),
    path("numbers", views.numbers, name='numbers'),
    #path("", views.index, name='index'),
]