from django.contrib import admin

# Register your models here.
from .models import Supervise

admin.site.register(Supervise)