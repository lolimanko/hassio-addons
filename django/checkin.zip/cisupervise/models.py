from django.db import models

# Create your models here.
class Supervise(models.Model):
    number = models.CharField(max_length=6)