from django.apps import AppConfig


class CisuperviseConfig(AppConfig):
    name = 'cisupervise'
