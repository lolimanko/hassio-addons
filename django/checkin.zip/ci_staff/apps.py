from django.apps import AppConfig


class Ci_staffConfig(AppConfig):
    name = 'ci_staff'
