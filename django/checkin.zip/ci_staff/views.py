from django.shortcuts import render
from django.http import HttpResponse
from django.http import JsonResponse
from .models import Staff
from django.core import serializers
import json,os
from django.forms.models import model_to_dict
# assuming obj is a model instance

# Create your views here.
def index(request):
    #latest_question_list = Question.objects.order_by("-pub_date")[:5]
    jsindex = 0 if ".js" in os.listdir("/media/vue-project/dist/assets")[0] else 1
    cssindex = 0 if ".css" in os.listdir("/media/vue-project/dist/assets")[0] else 1
    
    
    context = {"js": os.listdir("/media/vue-project/dist/assets")[jsindex],"css": os.listdir("/media/vue-project/dist/assets")[cssindex]}
    return render(request, "449674.html", context)
def number(request):
    if request.method == "GET":
    #data = serializers.serialize("json", Staff.objects.all(), fields=["number", "dates"])
    #jsondate = json.dumps(Staff.objects.get(number='449674'))
        nmodel = Staff.objects.get(number=request.GET['number'])
        ndict = model_to_dict(nmodel)
        pngs = [f.replace(".png", "") for f in os.listdir("/share/htdocs/"+request.GET['number'])]
        logs = sorted(pngs)
        
        ndict['log'] = logs
        njson = json.dumps(ndict)
        return JsonResponse(ndict, safe=True)
    if request.method == "PUT":
    #data = serializers.serialize("json", Staff.objects.all(), fields=["number", "dates"])
        try:
            # Decode the request body and parse the JSON data
            data = json.loads(request.body.decode('utf-8'))
            
            # Access the data as a Python dictionary
            numberpost = data.get('number')
            datespost = data.get('dates')
            new_datespost = [f.replace("T00:00:00.000Z", "") for f in datespost]
            #email = data.get('email')
            number = Staff.objects.get(number=numberpost)
            number.dates = new_datespost
            number.save()
            # Process your data (e.g., save to database)
            #print(f"Received data: Name - {name}, Email - {email}")
            return HttpResponse("put")
            #return JsonResponse({'message': 'Data received successfully!', 'name': name}, status=200)
        except json.JSONDecodeError:
            return JsonResponse({'error': 'Invalid JSON'}, status=400)
        