from django.db import models

# Create your models here.
class Staff(models.Model):
    number = models.CharField(max_length=6)
    is_dayshift = models.BooleanField(default=False)
    dates = models.JSONField(null=True, blank=True)
