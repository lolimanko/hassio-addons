"""
URL configuration for checkin13517 project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/6.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import include,path
from django.conf import settings
from django.conf.urls.static import static
import ci_staff.views
import cisupervise.views

urlpatterns = [
    path('admin/', admin.site.urls),
    path("ci_staff/", include("ci_staff.urls")),
    path("cisupervise/", include("cisupervise.urls")),
    path("449674", ci_staff.views.index, name='449674'),
    path("371098", ci_staff.views.index, name='371098'),
    path("301559", ci_staff.views.index, name='301559'),
    path("supervise", cisupervise.views.index, name='supervise'),
]


if not settings.DEBUG:
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
